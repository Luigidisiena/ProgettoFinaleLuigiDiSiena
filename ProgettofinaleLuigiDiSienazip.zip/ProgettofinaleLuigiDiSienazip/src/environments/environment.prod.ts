export const environment = {
  production: true,
  APIurl: 'http://epicode.online/epicodebeservice_v2'

};
