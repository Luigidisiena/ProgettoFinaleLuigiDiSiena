import { Clienti } from './clienti';

describe('Clienti', () => {
  it('should create an instance', () => {
    expect(new Clienti()).toBeTruthy();
  });
});
