
export class AdminLogin  {
    username: string = 'admin';
    password: string = '111111';
}
