import { StatoFattura } from './stato-fattura';

describe('StatoFattura', () => {
  it('should create an instance', () => {
    expect(new StatoFattura()).toBeTruthy();
  });
});
