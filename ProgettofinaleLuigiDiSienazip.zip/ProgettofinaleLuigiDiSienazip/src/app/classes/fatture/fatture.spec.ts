import { Fatture } from './fatture';

describe('Fatture', () => {
  it('should create an instance', () => {
    expect(new Fatture()).toBeTruthy();
  });
});
